# Instructions

## Things to do to prepare for the UBS interview
 - ensure that your machine has a Java JDK installed on it (we are assuming Java 7 will be used)
 - install an IDE of your choice to perform the interview (we have used Jetbrains Intellij)
 - included with this archive is an example project that is built using gradle, before the interview you should familiarise yourself with working on a Gradle project in the IDE of your choice.
 - when your environment is set up correctly running `gradlew check` from the command line should complete successfully.

## We value
 - simple, elegant code that reads like a narrative
 - thinking about the code more than the writing of the code (we spend a lot of time thinking/debating about what we are writing)
 - transparency and feedback to support continuous learning
 - excellent testing that acts as documentation
 - challenging boundaries where necessary

## What to expect from our process
 - we will have granted you access to a private repository under OpsIT.  This repository will be self describing what we want you to do
 - we will not measure how long it takes to complete the exercise, but we expect it back in a reasonable period of time
 - we would like you to think of this as production ready code
 - we will review your solution and feedback to you our thoughts
 - we will additionally feedback to you whether we would like to take the process further
 