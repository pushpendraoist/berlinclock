package com.ubs.opsit.interviews;

import org.apache.commons.validator.routines.TimeValidator;
import java.util.Locale;

public class BerlinClock implements TimeConverter {
	private static final String TIME_SAPARATOR = ":";
	private static final String NEW_LINE = System.getProperty("line.separator");
	private static final String RED_LAMP = "R";
	private static final String YELLOW_LAMP = "Y";
	public static String convertTime ;
	
	public BerlinClock(String aTime){
		BerlinClock.convertTime=convertTime(aTime);	
	}
	
	/**
	 * converts the time into the Berlin Clock format. 
	 * This method returns an string with combination of five Strings representing the lamp's state O (off), Y (yellow) and R (red).
	 * @param aTime The time to transform in the format HH:mm:ss
	 * @return The time in the Berlin Clock format.
	 */
	public String convertTime(String aTime) {
		verifyFormat(aTime);
		
		// retrieve hours , minutes , seconds from aTime String.
		String[] timeComponents = aTime.split(TIME_SAPARATOR);
		int hours = Integer.parseInt(timeComponents[0]);
		int minutes = Integer.parseInt(timeComponents[1]);
		int seconds = Integer.parseInt(timeComponents[2]);
		StringBuilder sb = new StringBuilder();
		String secLamp = getSeconsLamp(seconds);
		String fiveHoursLamps = getFiveHoursLamps(hours);
		String oneHourLamps = getOneHourLamps(hours);
		String fiveMinutesLamps = getFiveMinutesLamps(minutes);
		String oneMinuteLamps = getOneMinuteLamps(minutes);
		return sb.append(secLamp).append(fiveHoursLamps).append(oneHourLamps).append(fiveMinutesLamps).append(oneMinuteLamps).toString();
		//return String.join(","+Arrays.asList(secLamp, fiveHoursLamps, oneHourLamps, fiveMinutesLamps, oneMinuteLamps));
	}
	
	/**
	 * verify format of input time.
	 * This method to validate and parse the input time.
	 * @param aTime The time to transform in the format HH:mm:ss
	 * @return void
	 */
	private static void verifyFormat(String time) {
		if(time == null) throw new IllegalArgumentException("No time provided.");
		if (TimeValidator.getInstance().validate(time, "HH:mm:ss",
				Locale.forLanguageTag("de-DE")) == null &&!time.equals("24:00:00")) {
			throw new IllegalArgumentException("Cannot parse time " + time);
		}
	}
	
	/**
	 * 
	 * This method to generate top hour row string with Red Lamp
	 * The top two rows of lamps are red. These indicate the hours of a day. In
	 * the top row there are 4 red lamps. Every lamp represents 5 hours. So if
	 * two lamps of the first row and three of the second row are switched on
	 * that indicates 5+5+4=14h or 2 pm.
	 * @param hours 
	 * @return A string representing a top hour row of the clock.
	 */
	private static String getFiveHoursLamps(int hours) {
		StringBuilder result = new StringBuilder("OOOO");

		for (int i = 0; i < (hours / 5); i++) {
			result.replace(i, i + 1, RED_LAMP);
		}
		return result.toString();
	}
	
	/**
	 * 
	 * This method to generate bottom  hour row string with Red Lamp
	 * In the lower row of red lamps every lamp represents 1 hour. So if two
	 * lamps of the first row and three of the second row are switched on that
	 * indicates 5+5+5+1=16h or 4 pm.
	 * @param hours 
	 * @return A string representing a bottom hour row of the clock.
	 */

	private static String getOneHourLamps(int hours) {
		StringBuilder result = new StringBuilder("OOOO");

		for (int i = 0; i < (hours % 5); i++) {
			result.replace(i, i + 1, RED_LAMP);
		}
		return result.toString();
	}

	/**
	 * 
	 * This method to generate top minutes row string with Red and yellow lamp
	 * The two rows of lamps at the bottom count the minutes. The first of these
	 * rows has 11 lamps, the second 4. In the first row every lamp represents 5
	 * minutes. In this first row the 3rd, 6th and 9th lamp are red and indicate
	 * the first quarter, half and last quarter of an hour. The other lamps are
	 * yellow. Suppose minute number is 53 minute it means 10*5+3 then TOP 10
	 * rows are display and every 3rd and 6th and 9th rows are RED and other
	 * then is Yellow. replace YYY string with YYR it means every 3th occurrence
	 * of Y replace by R color.
	 * @param minutes 
	 * @return A string representing a top minute row of the clock.
	 */
	private static String getFiveMinutesLamps(int minutes) {
		StringBuilder result = new StringBuilder("OOOOOOOOOOO");

		for (int i = 0; i < (minutes / 5); i++) {
			if ((i + 1) % 3 == 0) {
				result.replace(i, i + 1, RED_LAMP);
			} else {
				result.replace(i, i + 1, YELLOW_LAMP);
			}
		}
		return result.toString();
	}
	/**
	 * 
	 * This method to generate bottom  minutes row string with yellow Lamp
	 * The two rows of lamps at the bottom count the minutes. The second rows is
	 * 4 with one minute. In the last row with 4 lamps every lamp represents 1
	 * minute. Suppose minute number is 53 minute it means 10*5+3 then only
	 * Bottom 3 rows are display with yellow color.
	 * @param minutes 
	 * @return A string representing a bottom minute row of the clock.
	 */
	private static String getOneMinuteLamps(int minutes) {
		StringBuilder result = new StringBuilder("OOOO");

		for (int i = 0; i < (minutes % 5); i++) {
			result.replace(i, i + 1, YELLOW_LAMP);
		}
		return result.toString();
	}
	/*
	 * if second timing is even then light will be ON with yellow color
	 * otherwise off.
	 * @param seconds 
	 * @return A string representing a second row of the clock.
	 */
	private static String getSeconsLamp(int seconds) {
		if (seconds % 2 == 0) {
			return YELLOW_LAMP;
		}
		return "O";
	}

	@Override
	public String toString() {
		return BerlinClock.convertTime;
	}
}
