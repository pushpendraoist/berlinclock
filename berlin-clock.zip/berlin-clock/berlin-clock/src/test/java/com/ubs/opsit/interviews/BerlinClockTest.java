package com.ubs.opsit.interviews;

import org.junit.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.Assert.assertEquals;

public class BerlinClockTest {

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();

    @Before
    public void setUpStreams() {
        System.setOut(new PrintStream(outContent));
        System.setErr(new PrintStream(errContent));
    }

    @Test
    public void testMinValidBerlinClock() {
        new BerlinClock("00:00:00");
    }

    @Test
    public void testMaxValidBerlinClock() {
        new BerlinClock("23:59:59");
    }

    @Test
    public void testValidBerlinClock() {
        BerlinClock clock = new BerlinClock("12:30:30");
        String expected = "Y"+
                "RROO"+
                "RROO"+
                "YYRYYROOOOO"+
                "OOOO";

        assertEquals(expected, clock.toString());
    }
    
    
    @Test
    public void testSomeTimes() throws Exception {
      // 16:36:35
      assertEquals("O"+"RRRO"+"ROOO"+"YYRYYRYOOOO"+"YOOO", new BerlinClock("16:36:35").toString());
      // 16:36:36
      assertEquals("Y"+"RRRO"+"ROOO"+"YYRYYRYOOOO"+"YOOO", new BerlinClock("16:36:36").toString());
      // 21:45:15
      assertEquals("O"+"RRRR"+"ROOO"+"YYRYYRYYROO"+"OOOO", new BerlinClock("21:45:15").toString());
      // 24:00:00
      assertEquals("Y"+"RRRR"+"RRRR"+"OOOOOOOOOOO"+"OOOO", new BerlinClock("24:00:00").toString());
    }
    
    
	public void testSeconds() throws Exception {
		// even seconds
		assertEquals( "Y"+"OOOO"+"OOOO"+"OOOOOOOOOOO"+"OOOO", new BerlinClock("00:00:00").toString());
		// uneven seconds
		assertEquals(  "O"+"OOOO"+"OOOO"+"OOOOOOOOOOO"+"OOOO",new BerlinClock("00:00:01").toString());
	}
	
	 @Test
	  public void testMinutes() throws Exception {
	    // zero minutes
	    assertEquals("Y"+"OOOO"+"OOOO"+"OOOOOOOOOOO"+"OOOO",new BerlinClock("00:00:00").toString());
	    // one minute
	 }
	 
	 @Test
	  public void testHours() throws Exception {
	    // modnight
	    assertEquals("Y"+"OOOO"+"OOOO"+"OOOOOOOOOOO"+"OOOO", new BerlinClock("00:00:00").toString());
	    // one o'clock
	    assertEquals("Y"+ "OOOO"+ "ROOO"+"OOOOOOOOOOO"+"OOOO", new BerlinClock("01:00:00").toString());
	    // two o'clock
	    assertEquals("Y"+"OOOO"+ "RROO"+"OOOOOOOOOOO"+"OOOO", new BerlinClock("02:00:00").toString());
	 }
    @Test
    public void testUpperInvalidHours() {
        new BerlinClock("24:00:00");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpperInvalidMinutes() {
        new BerlinClock("00:60:00");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testUpperInvalidSeconds() {
        new BerlinClock("00:00:60");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testLowerInvalidHours() {
        new BerlinClock("-01:00:00");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testLowerInvalidMinutes() {
        new BerlinClock("00:-01:00");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testLowerInvalidSeconds() {
        new BerlinClock("00:00:-01");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidString() {
        new BerlinClock("00:00");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNullString() {
        new BerlinClock(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEmptyString() {
        new BerlinClock("");
    }

    @After
    public void cleanUpStreams() {
        System.setOut(null);
        System.setErr(null);
    }

}
